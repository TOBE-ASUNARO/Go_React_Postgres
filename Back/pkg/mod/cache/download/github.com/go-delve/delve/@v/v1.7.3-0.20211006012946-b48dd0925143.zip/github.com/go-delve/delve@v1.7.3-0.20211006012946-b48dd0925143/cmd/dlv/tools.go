package main

// List packages used by _scripts

import (
	_ "github.com/spf13/cobra/doc"
)
